import { HubData } from '../types/hub';
import { INITIAL_HUB_DATA } from '../data/initialData';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore';

const STORAGE_KEY = 'curator_meddent_hub_v1';
const AUTH_KEY = 'curator_hub_admin_auth_status';
const STATE_DOC_PATH = 'hub_state';
const STATE_DOC_ID = 'main';

export function loadLocalHubData(): HubData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_HUB_DATA));
      return INITIAL_HUB_DATA;
    }
    const parsed = JSON.parse(raw) as HubData;
    if (!parsed.subjects || !parsed.lectures || !parsed.config) {
      return INITIAL_HUB_DATA;
    }
    parsed.config.adminPasscode = '20071507@a';
    return parsed;
  } catch (err) {
    console.error('Error loading hub data from localStorage:', err);
    return INITIAL_HUB_DATA;
  }
}

export function saveLocalHubData(data: HubData): boolean {
  try {
    const updated: HubData = {
      ...data,
      updatedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return true;
  } catch (err) {
    console.error('Error saving hub data to localStorage:', err);
    return false;
  }
}

/**
 * Subscribes to real-time changes from the cloud Firestore database.
 * When you change on phone, your PC updates automatically in real-time.
 */
export function subscribeToCloudHub(
  onUpdate: (data: HubData) => void,
  onSyncStatus?: (status: 'synced' | 'saving' | 'offline' | 'error') => void
): () => void {
  const docRef = doc(db, STATE_DOC_PATH, STATE_DOC_ID);

  const unsubscribe = onSnapshot(
    docRef,
    async (snapshot) => {
      if (snapshot.exists()) {
        const cloudData = snapshot.data() as HubData;
        if (cloudData.subjects && cloudData.lectures && cloudData.config) {
          // Keep passcode secure
          cloudData.config.adminPasscode = '20071507@a';
          saveLocalHubData(cloudData);
          onUpdate(cloudData);
          if (onSyncStatus) onSyncStatus('synced');
        }
      } else {
        // Document does not exist in Firestore yet: seed it with initial data!
        try {
          const initial = loadLocalHubData();
          await setDoc(docRef, initial);
          onUpdate(initial);
          if (onSyncStatus) onSyncStatus('synced');
        } catch (err) {
          console.error('Failed to seed cloud database:', err);
          if (onSyncStatus) onSyncStatus('error');
        }
      }
    },
    (error) => {
      console.warn('Real-time sync snapshot error (using offline cache):', error.message);
      if (onSyncStatus) onSyncStatus('offline');
      // Always fallback to local cache
      const cached = loadLocalHubData();
      onUpdate(cached);
    }
  );

  return unsubscribe;
}

/**
 * Saves changes to Firestore cloud so all devices (phones, PCs, students)
 * see the updates immediately!
 */
export async function saveHubDataToCloud(data: HubData): Promise<boolean> {
  const updated: HubData = {
    ...data,
    updatedAt: new Date().toISOString(),
  };

  // 1. Immediately cache locally
  saveLocalHubData(updated);

  // 2. Push to Firestore
  try {
    const docRef = doc(db, STATE_DOC_PATH, STATE_DOC_ID);
    await setDoc(docRef, updated);
    return true;
  } catch (err) {
    console.error('Error saving to cloud Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, `${STATE_DOC_PATH}/${STATE_DOC_ID}`);
    } catch {
      // ignore re-throw
    }
    return false;
  }
}

export async function resetCloudHubToDefault(): Promise<HubData> {
  saveLocalHubData(INITIAL_HUB_DATA);
  try {
    const docRef = doc(db, STATE_DOC_PATH, STATE_DOC_ID);
    await setDoc(docRef, INITIAL_HUB_DATA);
  } catch (err) {
    console.error('Error resetting cloud Firestore:', err);
  }
  return INITIAL_HUB_DATA;
}

export function checkAdminSession(): boolean {
  return sessionStorage.getItem(AUTH_KEY) === 'true';
}

export function setAdminSession(active: boolean): void {
  if (active) {
    sessionStorage.setItem(AUTH_KEY, 'true');
  } else {
    sessionStorage.removeItem(AUTH_KEY);
  }
}
