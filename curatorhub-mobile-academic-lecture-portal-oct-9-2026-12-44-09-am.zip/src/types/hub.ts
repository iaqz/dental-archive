export type AttachmentType = 'video' | 'pdf' | 'source' | 'slides' | 'drive' | 'link';

export interface AttachmentItem {
  id: string;
  title: string;
  url: string;
  type: AttachmentType;
  description?: string;
}

export interface ResourceLink {
  label: string;
  url: string;
  note?: string;
}

export interface Lecture {
  id: string;
  subjectId: string;
  lectureNumber: number;
  title: string;
  overview?: string;
  date?: string;
  // Beside-it primary action button
  primaryLink: ResourceLink;
  // MCQ button (linked to NotebookLM / Google Form / Quizlet)
  mcqLink?: ResourceLink;
  // Flashcard button (linked to NotebookLM / Study Guide / Anki)
  flashcardLink?: ResourceLink;
  // Additional attachments & video links
  attachments: AttachmentItem[];
  status?: 'completed' | 'in-progress' | 'upcoming';
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  description: string;
  iconName: string;
  themeColor: string; // 'amber' | 'terracotta' | 'sage' | 'bronze' | 'clay'
  order: number;
}

export interface FooterConfig {
  title: string;
  subtitle: string;
  batchOrClass: string;
  customNote: string;
  copyrightText: string;
}

export interface HubConfig {
  hubTitle: string;
  hubSubtitle: string;
  institutionName: string;
  announcement?: {
    text: string;
    active: boolean;
  };
  footerConfig: FooterConfig;
  adminPasscode: string;
}

export interface HubData {
  config: HubConfig;
  subjects: Subject[];
  lectures: Lecture[];
  version: number;
  updatedAt: string;
}
