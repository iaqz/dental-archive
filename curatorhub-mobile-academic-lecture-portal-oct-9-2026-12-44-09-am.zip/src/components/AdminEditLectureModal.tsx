import React, { useState, useEffect } from 'react';
import { Lecture, Subject } from '../types/hub';
import { BookOpen, Link2, Sparkles, Layers } from 'lucide-react';

interface AdminEditLectureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (lecture: Lecture) => void;
  subjects: Subject[];
  initialLecture?: Lecture | null;
  defaultSubjectId?: string;
}

export const AdminEditLectureModal: React.FC<AdminEditLectureModalProps> = ({
  isOpen,
  onClose,
  onSave,
  subjects,
  initialLecture,
  defaultSubjectId,
}) => {
  const [subjectId, setSubjectId] = useState(defaultSubjectId || subjects[0]?.id || '');
  const [lectureNumber, setLectureNumber] = useState(1);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [overview, setOverview] = useState('');

  // Primary link
  const [primaryLabel, setPrimaryLabel] = useState('Open Lecture Slides');
  const [primaryUrl, setPrimaryUrl] = useState('');

  // MCQ NotebookLM link
  const [mcqLabel, setMcqLabel] = useState('NotebookLM MCQs & Quiz');
  const [mcqUrl, setMcqUrl] = useState('');
  const [mcqNote, setMcqNote] = useState('');

  // Flashcards NotebookLM link
  const [fcLabel, setFcLabel] = useState('NotebookLM Flashcards');
  const [fcUrl, setFcUrl] = useState('');
  const [fcNote, setFcNote] = useState('');

  useEffect(() => {
    if (initialLecture) {
      setSubjectId(initialLecture.subjectId);
      setLectureNumber(initialLecture.lectureNumber);
      setTitle(initialLecture.title);
      setDate(initialLecture.date || '');
      setOverview(initialLecture.overview || '');
      setPrimaryLabel(initialLecture.primaryLink?.label || 'Open Lecture Slides');
      setPrimaryUrl(initialLecture.primaryLink?.url || '');
      setMcqLabel(initialLecture.mcqLink?.label || 'NotebookLM MCQs & Quiz');
      setMcqUrl(initialLecture.mcqLink?.url || '');
      setMcqNote(initialLecture.mcqLink?.note || '');
      setFcLabel(initialLecture.flashcardLink?.label || 'NotebookLM Flashcards');
      setFcUrl(initialLecture.flashcardLink?.url || '');
      setFcNote(initialLecture.flashcardLink?.note || '');
    } else {
      setSubjectId(defaultSubjectId || subjects[0]?.id || '');
      setLectureNumber(1);
      setTitle('');
      setDate('');
      setOverview('');
      setPrimaryLabel('Open Lecture Slides');
      setPrimaryUrl('');
      setMcqLabel('NotebookLM MCQs & Quiz');
      setMcqUrl('https://notebooklm.google.com');
      setMcqNote('Auto-generated practice quiz');
      setFcLabel('NotebookLM Flashcards');
      setFcUrl('https://notebooklm.google.com');
      setFcNote('Active recall & key terms');
    }
  }, [initialLecture, defaultSubjectId, subjects, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const savedLecture: Lecture = {
      id: initialLecture ? initialLecture.id : `lec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      subjectId,
      lectureNumber: Number(lectureNumber) || 1,
      title: title.trim(),
      date: date.trim() || undefined,
      overview: overview.trim() || undefined,
      primaryLink: {
        label: primaryLabel.trim() || 'Open Link',
        url: primaryUrl.trim(),
      },
      mcqLink: mcqUrl.trim() ? {
        label: mcqLabel.trim() || 'NotebookLM MCQs',
        url: mcqUrl.trim(),
        note: mcqNote.trim() || undefined,
      } : undefined,
      flashcardLink: fcUrl.trim() ? {
        label: fcLabel.trim() || 'NotebookLM Flashcards',
        url: fcUrl.trim(),
        note: fcNote.trim() || undefined,
      } : undefined,
      status: initialLecture?.status || 'completed',
      attachments: initialLecture?.attachments || [],
    };

    onSave(savedLecture);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-lg rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822] my-8 max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#ebdcc9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#f0e3d0] text-[#784315] flex items-center justify-center border border-[#decab1]">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#2d2822]">
                {initialLecture ? 'Edit Lecture' : 'Add New Lecture'}
              </h3>
              <p className="text-[11px] text-[#7d7162]">Configure title, primary button & NotebookLM links</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-xs text-[#8c8072] hover:text-[#2d2822] p-1 rounded hover:bg-[#f2ede4]"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Subject & Lecture Number */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="col-span-2">
              <label className="block font-semibold text-[#54483a] mb-1">
                Subject Department *
              </label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              >
                {subjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name} ({sub.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-[#54483a] mb-1">
                Lecture # *
              </label>
              <input
                type="number"
                min="1"
                required
                value={lectureNumber}
                onChange={(e) => setLectureNumber(Number(e.target.value))}
                className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              />
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Lecture Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Oral Mucosa & Epithelial Cell Junctions"
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          {/* Overview */}
          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Lecture Summary / Topics Covered
            </label>
            <textarea
              rows={2}
              value={overview}
              onChange={(e) => setOverview(e.target.value)}
              placeholder="Brief summary of what was covered..."
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl p-2.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          {/* 1. Beside-it Primary Link Button */}
          <div className="p-3 rounded-xl bg-[#f5ede2] border border-[#e5d6c2] space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-[#784315] text-[11px]">
              <Link2 className="w-3.5 h-3.5" />
              <span>Beside-It Primary Action Button</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">Button Label</label>
                <input
                  type="text"
                  value={primaryLabel}
                  onChange={(e) => setPrimaryLabel(e.target.value)}
                  placeholder="e.g. Open Slides, Notion Doc"
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">Target URL</label>
                <input
                  type="url"
                  value={primaryUrl}
                  onChange={(e) => setPrimaryUrl(e.target.value)}
                  placeholder="https://drive.google.com/..."
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
            </div>
          </div>

          {/* 2. MCQ / NotebookLM Quiz Button */}
          <div className="p-3 rounded-xl bg-[#f7f0e4] border border-[#e6d8c3] space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-[#784315] text-[11px]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>MCQs / NotebookLM Quiz Button</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">Button Label</label>
                <input
                  type="text"
                  value={mcqLabel}
                  onChange={(e) => setMcqLabel(e.target.value)}
                  placeholder="NotebookLM MCQs & Quiz"
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">NotebookLM / Quiz Link</label>
                <input
                  type="url"
                  value={mcqUrl}
                  onChange={(e) => setMcqUrl(e.target.value)}
                  placeholder="https://notebooklm.google.com/..."
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-[#706456] mb-0.5">Subtitle / Subtext Note</label>
              <input
                type="text"
                value={mcqNote}
                onChange={(e) => setMcqNote(e.target.value)}
                placeholder="e.g. Generated clinical test questions from slides"
                className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              />
            </div>
          </div>

          {/* 3. Flashcards / Study Guide Button */}
          <div className="p-3 rounded-xl bg-[#f4eee6] border border-[#e4d8c9] space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-[#544331] text-[11px]">
              <Layers className="w-3.5 h-3.5" />
              <span>Flashcards / Study Guide Button</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">Button Label</label>
                <input
                  type="text"
                  value={fcLabel}
                  onChange={(e) => setFcLabel(e.target.value)}
                  placeholder="NotebookLM Flashcards"
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#706456] mb-0.5">Flashcard / Guide Link</label>
                <input
                  type="url"
                  value={fcUrl}
                  onChange={(e) => setFcUrl(e.target.value)}
                  placeholder="https://notebooklm.google.com/..."
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-[#706456] mb-0.5">Subtitle / Subtext Note</label>
              <input
                type="text"
                value={fcNote}
                onChange={(e) => setFcNote(e.target.value)}
                placeholder="e.g. Active recall definitions and landmarks"
                className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              />
            </div>
          </div>

          {/* Submit / Cancel */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#ebdcc9]">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
            >
              {initialLecture ? 'Save Changes' : 'Create Lecture'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
