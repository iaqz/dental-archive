import React from 'react';
import { 
  Microscope, 
  Sparkles, 
  Smile, 
  Dna, 
  Bone, 
  HeartPulse, 
  Pill, 
  Brain, 
  BookOpen, 
  Stethoscope, 
  FlaskConical, 
  Activity,
  Layers
} from 'lucide-react';

export const ToothIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className}
    stroke="currentColor"
    strokeWidth="0.5"
  >
    <path d="M12 2C9.5 2 7.8 3.2 7 4.5C5.8 4.2 4.2 5 3.5 6.5C2.5 8.7 2.8 11.2 3.8 13.5C4.8 15.8 6.2 18.5 7 21C7.3 21.8 8.1 22 8.8 21.6C9.5 21.2 9.6 20.3 9.4 19.5C9 18 8.5 16.5 8.5 15C8.5 13.5 10 13 12 13C14 13 15.5 13.5 15.5 15C15.5 16.5 15 18 14.6 19.5C14.4 20.3 14.5 21.2 15.2 21.6C17 21.8 17.8 18.5 19.2 15.8C20.2 13.5 21.2 11.2 21.5 8.7C20.5 6.5 19.8 5 18.2 4.2C17 4.5 16.2 3.2 14.5 2 12 2Z" />
  </svg>
);

export const DentalMirrorIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="15" cy="9" r="6" />
    <path d="M10.5 13.5L3 21" />
    <path d="M12 6a4 4 0 0 1 4 4" />
  </svg>
);

export const DentalImplantIcon: React.FC<{ className?: string }> = ({ className = "w-4 h-4" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M7 3h10v4H7z" />
    <path d="M9 7v13l3 2 3-2V7" />
    <path d="M9 11h6" />
    <path d="M9 14h6" />
    <path d="M9 17h6" />
  </svg>
);

// Map icon string identifier to React component
export const AVAILABLE_SECTION_ICONS = [
  { id: 'tooth', label: 'Tooth / Dental', icon: (cls?: string) => <ToothIcon className={cls || "w-4 h-4"} /> },
  { id: 'dna', label: 'Biology / DNA', icon: (cls?: string) => <Dna className={cls || "w-4 h-4"} /> },
  { id: 'microscope', label: 'Microscope / Histology', icon: (cls?: string) => <Microscope className={cls || "w-4 h-4"} /> },
  { id: 'mirror', label: 'Dental Mirror', icon: (cls?: string) => <DentalMirrorIcon className={cls || "w-4 h-4"} /> },
  { id: 'implant', label: 'Dental Implant', icon: (cls?: string) => <DentalImplantIcon className={cls || "w-4 h-4"} /> },
  { id: 'bone', label: 'Bone / Anatomy', icon: (cls?: string) => <Bone className={cls || "w-4 h-4"} /> },
  { id: 'heart', label: 'Physiology', icon: (cls?: string) => <HeartPulse className={cls || "w-4 h-4"} /> },
  { id: 'pill', label: 'Pharmacology', icon: (cls?: string) => <Pill className={cls || "w-4 h-4"} /> },
  { id: 'flask', label: 'Biochemistry', icon: (cls?: string) => <FlaskConical className={cls || "w-4 h-4"} /> },
  { id: 'sparkles', label: 'Embryology', icon: (cls?: string) => <Sparkles className={cls || "w-4 h-4"} /> },
  { id: 'smile', label: 'Prosthodontics', icon: (cls?: string) => <Smile className={cls || "w-4 h-4"} /> },
  { id: 'stethoscope', label: 'Clinical Medicine', icon: (cls?: string) => <Stethoscope className={cls || "w-4 h-4"} /> },
  { id: 'brain', label: 'Neurology', icon: (cls?: string) => <Brain className={cls || "w-4 h-4"} /> },
  { id: 'book', label: 'General Study', icon: (cls?: string) => <BookOpen className={cls || "w-4 h-4"} /> },
];

export const renderSectionIcon = (iconId: string, className = "w-4 h-4") => {
  const match = AVAILABLE_SECTION_ICONS.find(item => item.id.toLowerCase() === iconId?.toLowerCase());
  if (match) {
    return match.icon(className);
  }
  // Fallbacks by common names
  if (iconId?.toLowerCase() === 'microscope') return <Microscope className={className} />;
  if (iconId?.toLowerCase() === 'sparkles') return <Sparkles className={className} />;
  if (iconId?.toLowerCase() === 'smile') return <Smile className={className} />;
  if (iconId?.toLowerCase() === 'dna') return <Dna className={className} />;
  return <ToothIcon className={className} />;
};
