import React from 'react';
import { Subject } from '../types/hub';
import { renderSectionIcon, ToothIcon } from './DentalIcons';
import { Plus, Settings } from 'lucide-react';

interface SubjectBarProps {
  subjects: Subject[];
  activeSubjectId: string | null;
  onSelectSubject: (id: string | null) => void;
  getLectureCount: (subjectId: string) => number;
  isAdmin: boolean;
  onAddSubject: () => void;
  onEditSubject: (subject: Subject) => void;
}

export const SubjectBar: React.FC<SubjectBarProps> = ({
  subjects,
  activeSubjectId,
  onSelectSubject,
  getLectureCount,
  isAdmin,
  onAddSubject,
  onEditSubject,
}) => {
  return (
    <div className="pt-2 pb-1">
      <div className="flex items-center justify-between gap-2 mb-2 px-1">
        <span className="text-[11px] font-bold tracking-wider text-[#8a7f72] uppercase flex items-center gap-1.5">
          <ToothIcon className="w-3.5 h-3.5 text-[#a85012]" />
          <span>Subjects & Categories</span>
        </span>
        {isAdmin && (
          <button
            onClick={onAddSubject}
            className="flex items-center gap-1 text-[11px] font-bold text-[#a85012] hover:text-[#78390c] transition cursor-pointer bg-[#f3ede3] hover:bg-[#ede5d8] px-2.5 py-1 rounded-lg border border-[#e2d5c4]"
          >
            <Plus className="w-3 h-3" />
            <span>Add Section (e.g. Biology)</span>
          </button>
        )}
      </div>

      {/* Grid of Sections: wraps responsively whether there are 3, 4, 5 or more sections! */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {subjects.map((sub) => {
          const isActive = activeSubjectId === sub.id;
          const lecCount = getLectureCount(sub.id);

          return (
            <div
              key={sub.id}
              onClick={() => onSelectSubject(isActive ? null : sub.id)}
              className={`relative flex flex-col p-2.5 rounded-2xl border transition-all cursor-pointer group text-left ${
                isActive
                  ? 'bg-[#f2e7d8] border-[#ceb696] shadow-xs ring-1 ring-[#c2621c]/40 text-[#2d2822]'
                  : 'bg-[#f7f2ea] border-[#e7ded1] hover:bg-[#f3ede3] hover:border-[#dbcbb7] text-[#4d4438]'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className={`p-1.5 rounded-xl transition ${
                  isActive ? 'bg-[#e5d6c2] text-[#803c0c]' : 'bg-[#eee6da] text-[#736859]'
                }`}>
                  {renderSectionIcon(sub.iconName, "w-4 h-4")}
                </div>
                {isAdmin && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onEditSubject(sub);
                    }}
                    className="p-1 rounded text-[#998d7f] hover:text-[#2d2822] hover:bg-[#eadecd] transition"
                    title="Edit Section & Icon"
                  >
                    <Settings className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="font-bold text-xs truncate">
                {sub.name}
              </div>

              <div className="text-[10px] text-[#8c8072] mt-0.5">
                {lecCount} {lecCount === 1 ? 'Lecture' : 'Lectures'}
              </div>
            </div>
          );
        })}

        {/* Quick Add Button inside the grid if Admin is active */}
        {isAdmin && (
          <button
            onClick={onAddSubject}
            className="flex flex-col items-center justify-center p-3 rounded-2xl border border-dashed border-[#d8c8b4] bg-[#fbf8f3] hover:bg-[#f3ede2] text-[#8a7a69] hover:text-[#2d2822] transition cursor-pointer min-h-[72px]"
          >
            <Plus className="w-4 h-4 mb-1 text-[#a85012]" />
            <span className="text-xs font-semibold">+ New Section</span>
          </button>
        )}
      </div>
    </div>
  );
};
