import React from 'react';
import { Search, SlidersHorizontal, LogOut, Cloud } from 'lucide-react';
import { HubConfig } from '../types/hub';
import { ToothIcon } from './DentalIcons';

interface HeaderProps {
  config: HubConfig;
  onSelectSubject: (id: string | null) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  isAdmin: boolean;
  onOpenSettings: () => void;
  onLogoutAdmin: () => void;
  syncStatus?: 'synced' | 'saving' | 'offline' | 'error';
}

export const Header: React.FC<HeaderProps> = ({
  config,
  onSelectSubject,
  searchQuery,
  onSearchChange,
  isAdmin,
  onOpenSettings,
  onLogoutAdmin,
  syncStatus = 'synced',
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#faf7f2]/95 backdrop-blur-md border-b border-[#e8e2d8] transition-all">
      {/* Top Admin Sticky Notification Strip if Admin is Active */}
      {isAdmin && (
        <div className="bg-[#ede1cd] border-b border-[#d8c3a5] px-3.5 py-1.5 text-xs text-[#6e390c] flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 font-semibold truncate">
            <span className="w-2 h-2 rounded-full bg-[#c2621c] animate-pulse shrink-0" />
            <span className="truncate">Admin Mode Active (Live Cloud)</span>
          </div>
          <button
            onClick={onLogoutAdmin}
            className="px-2 py-0.5 rounded-lg bg-[#c2621c] hover:bg-[#ad5313] text-white text-[11px] font-semibold transition cursor-pointer shadow-2xs active:scale-95 shrink-0 flex items-center gap-1"
          >
            <LogOut className="w-3 h-3" />
            <span>Return to Viewer</span>
          </button>
        </div>
      )}

      {/* Warm Announcement Banner (for everyone) */}
      {!isAdmin && config.announcement && config.announcement.active && config.announcement.text && (
        <div className="bg-[#f5ede0] border-b border-[#ebdcc8] px-3.5 py-1.5 text-xs text-[#8a5323] flex items-center justify-between gap-2 overflow-hidden">
          <div className="flex items-center gap-1.5 truncate">
            <span className="flex h-1.5 w-1.5 rounded-full bg-[#c2621c] shrink-0" />
            <span className="truncate font-medium">{config.announcement.text}</span>
          </div>
        </div>
      )}

      {/* Main Top Title Bar */}
      <div className="px-4 py-3 flex items-center justify-between gap-3 max-w-xl mx-auto">
        <div 
          onClick={() => onSelectSubject(null)}
          className="flex items-center gap-2.5 cursor-pointer group select-none min-w-0"
        >
          <div className="w-9 h-9 rounded-xl bg-[#eadecd] text-[#784315] flex items-center justify-center border border-[#dac7ae] shadow-xs shrink-0 group-hover:bg-[#dfd0bd] transition-colors">
            <ToothIcon className="w-5 h-5 text-[#8a420b]" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base tracking-tight text-[#2d2822] truncate group-hover:text-[#a85012] transition-colors">
                {config.hubTitle}
              </h1>
              {/* Cloud Sync indicator */}
              <span 
                className="hidden xs:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] bg-[#f0e7d8] text-[#73593b] border border-[#e2d4c0] shrink-0"
                title="Synchronized live cloud database across phone and PC"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Live</span>
              </span>
            </div>
            <p className="text-[11px] text-[#7e7467] truncate">
              {config.institutionName || 'Dental & Medical Academic Portal'}
            </p>
          </div>
        </div>

        {/* Header Admin Quick Buttons */}
        {isAdmin && (
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={onOpenSettings}
              className="p-1.5 rounded-lg bg-[#f3ede4] border border-[#e1d5c4] text-[#695f53] hover:text-[#2d2822] hover:bg-[#eae2d5] transition cursor-pointer"
              title="Hub Settings"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Warm Search Bar */}
      <div className="px-4 pb-3 max-w-xl mx-auto">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#9c9183] pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search lectures, topics, NotebookLM quizzes..."
            className="w-full bg-[#f4eee6] border border-[#e5dcce] rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-[#2d2822] placeholder:text-[#9e9385] focus:outline-none focus:border-[#c2621c] focus:bg-[#faf6f0] transition shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[#8c8072] hover:text-[#2d2822] p-1"
            >
              ✕
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
