import React from 'react';
import { Trash2, AlertTriangle } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  title,
  message,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-sm rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822]"
      >
        <div className="flex items-center gap-2.5 mb-3">
          <div className="w-8 h-8 rounded-xl bg-[#fae5e3] text-[#b9382f] flex items-center justify-center border border-[#f3c8c5]">
            <Trash2 className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-[#2d2822]">{title}</h3>
            <p className="text-[11px] text-[#7d7162]">Confirm deletion</p>
          </div>
        </div>

        <p className="text-xs text-[#54483a] leading-relaxed mb-4">
          {message}
        </p>

        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#b9382f] hover:bg-[#a12f27] text-white transition shadow-2xs active:scale-95 cursor-pointer"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};
