import React, { useState, useEffect } from 'react';
import { FileEdit, MessageSquare } from 'lucide-react';

interface EditNoticeModalProps {
  isOpen: boolean;
  currentNotice: string;
  onClose: () => void;
  onSave: (newNotice: string) => void;
}

export const EditNoticeModal: React.FC<EditNoticeModalProps> = ({
  isOpen,
  currentNotice,
  onClose,
  onSave,
}) => {
  const [notice, setNotice] = useState(currentNotice);

  useEffect(() => {
    setNotice(currentNotice);
  }, [currentNotice, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(notice.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-sm rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822]"
      >
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#ebdcc9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#f0e3d0] text-[#784315] flex items-center justify-center border border-[#decab1]">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#2d2822]">Edit Footer Notice</h3>
              <p className="text-[11px] text-[#7d7162]">Update message for students</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-xs text-[#8c8072] hover:text-[#2d2822] p-1 rounded hover:bg-[#f2ede4]"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Notice Text
            </label>
            <textarea
              rows={3}
              required
              value={notice}
              onChange={(e) => setNotice(e.target.value)}
              placeholder="Notice to students..."
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl p-2.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#ebdcc9]">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
            >
              Save Notice
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
