import React, { useState } from 'react';
import { HubConfig } from '../types/hub';
import { SlidersHorizontal, KeyRound, Sparkles } from 'lucide-react';

interface AdminHubSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: HubConfig;
  onSaveConfig: (newConfig: HubConfig) => void;
  onResetHub: () => void;
}

export const AdminHubSettingsModal: React.FC<AdminHubSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onResetHub,
}) => {
  const [hubTitle, setHubTitle] = useState(config.hubTitle);
  const [institutionName, setInstitutionName] = useState(config.institutionName);
  const [announcementText, setAnnouncementText] = useState(config.announcement?.text || '');
  const [announcementActive, setAnnouncementActive] = useState(config.announcement?.active ?? true);
  
  // Footer settings
  const [footerTitle, setFooterTitle] = useState(config.footerConfig.title);
  const [footerSubtitle, setFooterSubtitle] = useState(config.footerConfig.subtitle);
  const [batchOrClass, setBatchOrClass] = useState(config.footerConfig.batchOrClass);
  const [customNote, setCustomNote] = useState(config.footerConfig.customNote);
  const [copyrightText, setCopyrightText] = useState(config.footerConfig.copyrightText);

  // Passcode
  const [adminPasscode, setAdminPasscode] = useState(config.adminPasscode);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const updatedConfig: HubConfig = {
      hubTitle: hubTitle.trim() || 'Academic Study Hub',
      hubSubtitle: config.hubSubtitle,
      institutionName: institutionName.trim(),
      announcement: {
        text: announcementText.trim(),
        active: announcementActive && !!announcementText.trim(),
      },
      adminPasscode: adminPasscode.trim() || '20071507@a',
      footerConfig: {
        title: footerTitle.trim() || 'Academic Study Hub',
        subtitle: footerSubtitle.trim(),
        batchOrClass: batchOrClass.trim(),
        customNote: customNote.trim(),
        copyrightText: copyrightText.trim() || 'DentMed Hub',
      },
    };

    onSaveConfig(updatedConfig);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-lg rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822] my-6 max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#ebdcc9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#f0e3d0] text-[#784315] flex items-center justify-center border border-[#decab1]">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#2d2822]">
                Hub & Footer Settings
              </h3>
              <p className="text-[11px] text-[#7d7162]">Custom titles, notices, and admin passcode</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-xs text-[#8c8072] hover:text-[#2d2822] p-1 rounded hover:bg-[#f2ede4]"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Header Branding */}
          <div className="p-3 rounded-xl bg-[#f7f2ea] border border-[#e4d8c7] space-y-2.5">
            <span className="font-bold text-[#784315] uppercase tracking-wider block text-[11px]">
              Hub Header Identity
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[#5c5040] mb-0.5">Hub Title</label>
                <input
                  type="text"
                  required
                  value={hubTitle}
                  onChange={(e) => setHubTitle(e.target.value)}
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>

              <div>
                <label className="block text-[#5c5040] mb-0.5">Faculty / Institution</label>
                <input
                  type="text"
                  value={institutionName}
                  onChange={(e) => setInstitutionName(e.target.value)}
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
            </div>
          </div>

          {/* Announcement Banner */}
          <div className="p-3 rounded-xl bg-[#f7f2ea] border border-[#e4d8c7] space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[#784315] uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Top Announcement Bar
              </span>
              <label className="flex items-center gap-1.5 text-[#5c5040] cursor-pointer">
                <input
                  type="checkbox"
                  checked={announcementActive}
                  onChange={(e) => setAnnouncementActive(e.target.checked)}
                  className="rounded text-[#c2621c] focus:ring-0"
                />
                <span>Active</span>
              </label>
            </div>

            <input
              type="text"
              placeholder="e.g. NotebookLM study spaces updated for all lectures!"
              value={announcementText}
              onChange={(e) => setAnnouncementText(e.target.value)}
              className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          {/* Footer Settings */}
          <div className="p-3 rounded-xl bg-[#f7f2ea] border border-[#e4d8c7] space-y-2.5">
            <span className="font-bold text-[#784315] uppercase tracking-wider block text-[11px]">
              Footer Settings
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-[#5c5040] mb-0.5">Footer Title</label>
                <input
                  type="text"
                  value={footerTitle}
                  onChange={(e) => setFooterTitle(e.target.value)}
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
              <div>
                <label className="block text-[#5c5040] mb-0.5">Batch / Class Tag</label>
                <input
                  type="text"
                  value={batchOrClass}
                  onChange={(e) => setBatchOrClass(e.target.value)}
                  className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[#5c5040] mb-0.5">Footer Notice Box</label>
              <textarea
                rows={2}
                value={customNote}
                onChange={(e) => setCustomNote(e.target.value)}
                placeholder="Notice to students..."
                className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              />
            </div>

            <div>
              <label className="block text-[#5c5040] mb-0.5">Copyright Text</label>
              <input
                type="text"
                value={copyrightText}
                onChange={(e) => setCopyrightText(e.target.value)}
                className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
              />
            </div>
          </div>

          {/* Passcode */}
          <div className="p-3 rounded-xl bg-[#f7f2ea] border border-[#e4d8c7] space-y-1.5">
            <span className="font-bold text-[#784315] uppercase tracking-wider block text-[11px] flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5" />
              Admin Passcode
            </span>
            <input
              type="text"
              value={adminPasscode}
              onChange={(e) => setAdminPasscode(e.target.value)}
              className="w-full bg-[#fffdfa] border border-[#d8c8b4] rounded-lg px-2.5 py-1.5 text-xs font-mono text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          {/* Reset & Submit */}
          <div className="flex items-center justify-between pt-3 border-t border-[#ebdcc9]">
            <button
              type="button"
              onClick={() => {
                if (confirm('Reset hub data back to sample template?')) {
                  onResetHub();
                  onClose();
                }
              }}
              className="text-xs text-[#b9382f] hover:underline cursor-pointer"
            >
              Reset to Defaults
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
              >
                Save Settings
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
