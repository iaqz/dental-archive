import React, { useState, useEffect } from 'react';
import { AttachmentItem, AttachmentType } from '../types/hub';
import { Paperclip, Video, FileText, BookMarked, Link as LinkIcon } from 'lucide-react';

interface AdminEditAttachmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (attachment: AttachmentItem) => void;
  initialAttachment?: AttachmentItem | null;
}

export const AdminEditAttachmentModal: React.FC<AdminEditAttachmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialAttachment,
}) => {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [type, setType] = useState<AttachmentType>('video');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (initialAttachment) {
      setTitle(initialAttachment.title);
      setUrl(initialAttachment.url);
      setType(initialAttachment.type);
      setDescription(initialAttachment.description || '');
    } else {
      setTitle('');
      setUrl('');
      setType('video');
      setDescription('');
    }
  }, [initialAttachment, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !url.trim()) return;

    const saved: AttachmentItem = {
      id: initialAttachment ? initialAttachment.id : `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      url: url.trim(),
      type,
      description: description.trim() || undefined,
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-md rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822]"
      >
        <div className="flex items-center justify-between mb-3 pb-3 border-b border-[#ebdcc9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#f0e3d0] text-[#784315] flex items-center justify-center border border-[#decab1]">
              <Paperclip className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#2d2822]">
                {initialAttachment ? 'Edit Resource' : 'Add Video or Source Link'}
              </h3>
              <p className="text-[11px] text-[#7d7162]">Add video lecture, textbook, or drive link</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-xs text-[#8c8072] hover:text-[#2d2822] p-1 rounded hover:bg-[#f2ede4]"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Resource Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. 3D Amelogenesis Video or Chapter 7 PDF"
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Resource Type
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { type: 'video' as AttachmentType, label: 'Video', icon: <Video className="w-3.5 h-3.5" /> },
                { type: 'pdf' as AttachmentType, label: 'PDF', icon: <FileText className="w-3.5 h-3.5" /> },
                { type: 'source' as AttachmentType, label: 'Book', icon: <BookMarked className="w-3.5 h-3.5" /> },
                { type: 'link' as AttachmentType, label: 'Link', icon: <LinkIcon className="w-3.5 h-3.5" /> },
              ].map((item) => (
                <button
                  type="button"
                  key={item.type}
                  onClick={() => setType(item.type)}
                  className={`flex items-center gap-1.5 p-2 rounded-xl border text-xs justify-center transition cursor-pointer ${
                    type === item.type
                      ? 'bg-[#edd8be] border-[#c49e70] text-[#784315] font-bold'
                      : 'bg-[#f7f2ea] border-[#e2d7c7] text-[#736655] hover:text-[#2d2822]'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Link URL *
            </label>
            <input
              type="url"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://youtube.com/..., https://drive.google.com/..."
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Optional Note / Description
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Recommended timestamp 12:40 for border tracing"
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#ebdcc9]">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
            >
              {initialAttachment ? 'Save Resource' : 'Add Resource'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
