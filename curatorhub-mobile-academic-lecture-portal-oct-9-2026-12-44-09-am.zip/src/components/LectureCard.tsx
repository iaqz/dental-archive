import React, { useState } from 'react';
import { Lecture, AttachmentItem } from '../types/hub';
import { ToothIcon, DentalMirrorIcon } from './DentalIcons';
import { 
  ExternalLink, 
  Sparkles, 
  Layers, 
  Paperclip, 
  Edit3, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  Video, 
  FileText, 
  BookMarked, 
  Link as LinkIcon 
} from 'lucide-react';

interface LectureCardProps {
  lecture: Lecture;
  isAdmin: boolean;
  onEditLecture: (lecture: Lecture) => void;
  onRequestDelete: (id: string, title: string) => void;
  onAddAttachment: () => void;
  onEditAttachment: (att: AttachmentItem) => void;
  onDeleteAttachment: (attId: string) => void;
}

export const LectureCard: React.FC<LectureCardProps> = ({
  lecture,
  isAdmin,
  onEditLecture,
  onRequestDelete,
  onAddAttachment,
  onEditAttachment,
  onDeleteAttachment,
}) => {
  const [showAttachments, setShowAttachments] = useState(false);
  const attCount = lecture.attachments?.length || 0;

  return (
    <div className="rounded-2xl bg-[#fcfaf6] border border-[#e8dfd3] shadow-xs hover:border-[#ded2c3] transition-all p-4 space-y-3">
      {/* Top Header: Badge, Title, and Admin Actions */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 mb-1">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-[#eee5d8] text-[#734316]">
              <ToothIcon className="w-3 h-3 text-[#a85012]" />
              <span>Lec #{lecture.lectureNumber}</span>
            </span>
            {lecture.date && (
              <span className="text-[11px] text-[#8c8172]">
                {lecture.date}
              </span>
            )}
          </div>

          <h3 className="text-base font-bold text-[#2d2822] leading-snug">
            {lecture.title}
          </h3>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <div className="flex items-center gap-1 shrink-0 pt-0.5">
            <button
              onClick={() => onEditLecture(lecture)}
              className="p-1.5 rounded-lg text-[#786c5f] hover:text-[#2d2822] hover:bg-[#ede5d8] transition cursor-pointer"
              title="Edit Lecture"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onRequestDelete(lecture.id, lecture.title)}
              className="p-1.5 rounded-lg text-[#b9382f] hover:text-white hover:bg-[#b9382f] transition cursor-pointer"
              title="Delete Lecture"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Summary if present */}
      {lecture.overview && (
        <p className="text-xs text-[#6e6355] leading-relaxed">
          {lecture.overview}
        </p>
      )}

      {/* Primary Lecture Slides Link (Clean & Simple) */}
      {lecture.primaryLink && lecture.primaryLink.url && (
        <div className="pt-0.5">
          <a
            href={lecture.primaryLink.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#8a420b] hover:text-[#5e2d07] hover:underline"
          >
            <DentalMirrorIcon className="w-3.5 h-3.5" />
            <span>{lecture.primaryLink.label || 'Open Lecture Slides'}</span>
            <ExternalLink className="w-3 h-3 opacity-70" />
          </a>
        </div>
      )}

      {/* NotebookLM MCQs & Flashcards Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-[#ede4d8]">
        {/* MCQs Button */}
        {lecture.mcqLink && lecture.mcqLink.url ? (
          <a
            href={lecture.mcqLink.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-2.5 rounded-xl bg-[#f5ede0] border border-[#e6d8c3] hover:bg-[#eee1cf] text-[#784315] transition-all group"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="p-1.5 rounded-lg bg-[#ebd9c1] text-[#784315]">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#3d2714] truncate">
                  {lecture.mcqLink.label || 'NotebookLM MCQs & Quiz'}
                </div>
                <div className="text-[10px] text-[#8f6946] truncate">
                  {lecture.mcqLink.note || 'Practice interactive quiz'}
                </div>
              </div>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-[#8f6946] group-hover:translate-x-0.5 transition-transform shrink-0 ml-1.5" />
          </a>
        ) : (
          isAdmin && (
            <button
              onClick={() => onEditLecture(lecture)}
              className="p-2 rounded-xl bg-[#f7f2ea] border border-dashed border-[#ded4c5] text-center text-xs text-[#8c8072] hover:text-[#2d2822]"
            >
              + Set NotebookLM MCQs Link
            </button>
          )
        )}

        {/* Flashcards Button */}
        {lecture.flashcardLink && lecture.flashcardLink.url ? (
          <a
            href={lecture.flashcardLink.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-2.5 rounded-xl bg-[#f2ede4] border border-[#e2d8cb] hover:bg-[#ebe2d4] text-[#524434] transition-all group"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="p-1.5 rounded-lg bg-[#e2d7c7] text-[#544331]">
                <Layers className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-[#2d2822] truncate">
                  {lecture.flashcardLink.label || 'NotebookLM Flashcards'}
                </div>
                <div className="text-[10px] text-[#7a6f61] truncate">
                  {lecture.flashcardLink.note || 'Active recall study space'}
                </div>
              </div>
            </div>
            <ExternalLink className="w-3.5 h-3.5 text-[#7a6f61] group-hover:translate-x-0.5 transition-transform shrink-0 ml-1.5" />
          </a>
        ) : (
          isAdmin && (
            <button
              onClick={() => onEditLecture(lecture)}
              className="p-2 rounded-xl bg-[#f7f2ea] border border-dashed border-[#ded4c5] text-center text-xs text-[#8c8072] hover:text-[#2d2822]"
            >
              + Set Flashcards Link
            </button>
          )
        )}
      </div>

      {/* Attachments / Videos / Sources Subsection */}
      <div className="pt-1 border-t border-[#ede4d8]">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setShowAttachments(!showAttachments)}
            className="flex items-center gap-1.5 text-xs font-semibold text-[#706456] hover:text-[#2d2822] py-1 cursor-pointer"
          >
            <Paperclip className="w-3.5 h-3.5 text-[#a85012]" />
            <span>Attachments & Sources ({attCount})</span>
            {showAttachments ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 opacity-70" />
            )}
          </button>

          {isAdmin && (
            <button
              onClick={onAddAttachment}
              className="text-[11px] font-semibold text-[#a85012] hover:underline cursor-pointer"
            >
              + Add Link
            </button>
          )}
        </div>

        {/* Dropdown list */}
        {showAttachments && (
          <div className="mt-2 space-y-1.5">
            {attCount === 0 ? (
              <p className="text-xs text-[#8c8072] text-center py-2 bg-[#f8f4ed] rounded-xl">
                No attachments added yet.
              </p>
            ) : (
              lecture.attachments.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center justify-between gap-2 p-2 rounded-xl bg-[#fffdfa] border border-[#e8ded2] text-xs hover:border-[#dbcebf] transition"
                >
                  <a
                    href={att.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-[#383129] hover:text-[#a85012] min-w-0 flex-1 truncate"
                  >
                    <span className="p-1 rounded bg-[#f3ede3] text-[#736859] shrink-0">
                      {att.type === 'video' ? <Video className="w-3 h-3 text-[#b9382f]" /> :
                       att.type === 'pdf' ? <FileText className="w-3 h-3 text-[#b45309]" /> :
                       att.type === 'source' ? <BookMarked className="w-3 h-3 text-[#524434]" /> :
                       <LinkIcon className="w-3 h-3 text-[#a85012]" />}
                    </span>
                    <div className="truncate">
                      <div className="font-semibold truncate">{att.title}</div>
                      {att.description && (
                        <div className="text-[10px] text-[#8a7e70] truncate">{att.description}</div>
                      )}
                    </div>
                    <ExternalLink className="w-3 h-3 opacity-50 shrink-0 ml-1" />
                  </a>

                  {isAdmin && (
                    <div className="flex items-center gap-0.5 shrink-0">
                      <button
                        onClick={() => onEditAttachment(att)}
                        className="p-1 text-[#8c8072] hover:text-[#2d2822]"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onDeleteAttachment(att.id)}
                        className="p-1 text-[#8c8072] hover:text-[#b9382f]"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
