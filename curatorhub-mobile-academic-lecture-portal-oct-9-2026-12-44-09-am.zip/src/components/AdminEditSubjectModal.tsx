import React, { useState, useEffect } from 'react';
import { Subject } from '../types/hub';
import { AVAILABLE_SECTION_ICONS, renderSectionIcon, ToothIcon } from './DentalIcons';
import { Plus, Trash2, Layers } from 'lucide-react';

interface AdminEditSubjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: Subject) => void;
  onDelete?: (id: string) => void;
  initialSubject?: Subject | null;
}

export const AdminEditSubjectModal: React.FC<AdminEditSubjectModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialSubject,
}) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [iconId, setIconId] = useState('tooth');

  useEffect(() => {
    if (initialSubject) {
      setName(initialSubject.name);
      setCode(initialSubject.code || '');
      setDescription(initialSubject.description || '');
      setIconId(initialSubject.iconName?.toLowerCase() || 'tooth');
    } else {
      setName('');
      setCode('');
      setDescription('');
      setIconId('dna');
    }
  }, [initialSubject, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const cleanName = name.trim();
    // Unique ID generation ensuring no collisions
    const generatedId = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '-') || `subj-${Date.now()}`;
    const subjectId = initialSubject ? initialSubject.id : `${generatedId}-${Date.now().toString(36).substring(4)}`;

    const saved: Subject = {
      id: subjectId,
      name: cleanName,
      code: code.trim() || cleanName.substring(0, 4).toUpperCase(),
      description: description.trim(),
      themeColor: 'terracotta',
      iconName: iconId,
      order: initialSubject ? initialSubject.order : Date.now(),
    };

    onSave(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2b2620]/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        onClick={(e) => e.stopPropagation()} 
        className="w-full max-w-md rounded-2xl bg-[#fdfbf7] border border-[#e8dfd3] p-5 shadow-xl text-[#2d2822] max-h-[92vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-3 pb-3 border-b border-[#ebdcc9]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#f0e3d0] text-[#784315] flex items-center justify-center border border-[#decab1]">
              {renderSectionIcon(iconId, "w-4 h-4 text-[#8a420b]")}
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#2d2822]">
                {initialSubject ? 'Edit Section' : 'Add New Section'}
              </h3>
              <p className="text-[11px] text-[#7d7162]">
                {initialSubject ? 'Update name & icon' : 'Add Biology, Anatomy, etc.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-xs text-[#8c8072] hover:text-[#2d2822] p-1 rounded hover:bg-[#f2ede4]"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* Section Name & Code */}
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block font-semibold text-[#54483a] mb-1">
                Section Name *
              </label>
              <input
                type="text"
                required
                autoFocus
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (!code && !initialSubject) {
                    setCode(e.target.value.substring(0, 4).toUpperCase());
                  }
                }}
                placeholder="e.g. Biology, Histology"
                className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c] focus:bg-[#fffdfa]"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#54483a] mb-1">
                Short Code
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="BIO-101"
                className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c] focus:bg-[#fffdfa]"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block font-semibold text-[#54483a] mb-1">
              Description (Optional)
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Cellular biology, genetics, and dental anatomy"
              className="w-full bg-[#f7f2ea] border border-[#e2d7c7] rounded-xl px-3 py-2 text-xs text-[#2d2822] focus:outline-none focus:border-[#c2621c] focus:bg-[#fffdfa]"
            />
          </div>

          {/* Icon Picker (Dental, Biology, Medicine) */}
          <div>
            <label className="block font-semibold text-[#54483a] mb-1.5 flex items-center justify-between">
              <span>Choose Section Icon</span>
              <span className="text-[10px] text-[#8a7e70] font-normal">Tap icon to select</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-2 gap-1.5 max-h-48 overflow-y-auto p-1.5 bg-[#f7f2ea] rounded-xl border border-[#e2d7c7]">
              {AVAILABLE_SECTION_ICONS.map((item) => {
                const isSelected = iconId.toLowerCase() === item.id.toLowerCase();
                return (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => setIconId(item.id)}
                    className={`flex items-center gap-2 p-2 rounded-xl text-left transition cursor-pointer border ${
                      isSelected
                        ? 'bg-[#edd8be] border-[#c49e70] text-[#784315] font-bold shadow-2xs'
                        : 'bg-[#fffdfa] border-[#e8dfd3] text-[#695d4e] hover:bg-[#f4ede3]'
                    }`}
                  >
                    <div className="shrink-0">
                      {item.icon("w-4 h-4")}
                    </div>
                    <span className="text-[11px] truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-[#ebdcc9]">
            {initialSubject && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onDelete(initialSubject.id);
                  onClose();
                }}
                className="flex items-center gap-1 text-xs text-[#b9382f] hover:underline p-1 cursor-pointer font-semibold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Section</span>
              </button>
            ) : <div />}

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[#7d7162] hover:bg-[#ede5d8] transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
              >
                {initialSubject ? 'Save Changes' : 'Create Section'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
