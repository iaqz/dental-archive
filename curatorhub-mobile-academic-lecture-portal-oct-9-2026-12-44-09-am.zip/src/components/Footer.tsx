import React from 'react';
import { FooterConfig } from '../types/hub';
import { Lock, SlidersHorizontal, Edit2, LogOut } from 'lucide-react';
import { ToothIcon } from './DentalIcons';

interface FooterProps {
  footerConfig: FooterConfig;
  isAdmin: boolean;
  onOpenAdminLogin: () => void;
  onOpenSettings: () => void;
  onOpenEditNotice: () => void;
  onExitAdminMode: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  footerConfig,
  isAdmin,
  onOpenAdminLogin,
  onOpenSettings,
  onOpenEditNotice,
  onExitAdminMode,
}) => {
  return (
    <footer className="mt-12 border-t border-[#e8dfd3] bg-[#faf6f0] text-[#736859]">
      <div className="max-w-xl mx-auto px-4 py-6">
        {/* Notice Box with Edit capability */}
        {footerConfig.customNote && (
          <div className="p-3.5 rounded-2xl bg-[#f2ebd9]/80 border border-[#e4d7bf] text-xs text-[#635747] leading-relaxed mb-4 flex items-start justify-between gap-3">
            <div>
              <span className="font-bold text-[#784315] flex items-center gap-1.5 mb-0.5">
                <ToothIcon className="w-3.5 h-3.5 text-[#a85012]" />
                Notice
              </span>
              <p className="text-xs text-[#54483a]">{footerConfig.customNote}</p>
            </div>
            {isAdmin && (
              <button
                onClick={onOpenEditNotice}
                className="shrink-0 text-[11px] font-semibold text-[#8a420b] hover:text-[#5e2d07] flex items-center gap-1 p-1 rounded hover:bg-[#eadecd] transition cursor-pointer"
                title="Edit Notice"
              >
                <Edit2 className="w-3 h-3" />
                <span>Edit</span>
              </button>
            )}
          </div>
        )}

        {/* Clean Action Toolbar (Backup option completely removed) */}
        <div className="pt-2 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            {isAdmin ? (
              <div className="flex items-center gap-2">
                <button
                  onClick={onExitAdminMode}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] text-xs font-semibold transition cursor-pointer shadow-2xs active:scale-95"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Return to Viewer Mode</span>
                </button>

                <button
                  onClick={onOpenSettings}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#eee5d8] hover:bg-[#e4d7c6] border border-[#decbb4] text-[#4d4233] text-xs font-medium transition cursor-pointer"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Settings</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAdminLogin}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#f2e9db] hover:bg-[#e9decb] border border-[#d8c7af] text-[#544331] hover:text-[#2d2822] text-xs font-semibold transition cursor-pointer shadow-2xs active:scale-95"
              >
                <Lock className="w-3.5 h-3.5 text-[#a85012]" />
                <span>Manage Contents</span>
              </button>
            )}
          </div>

          <div className="text-right text-[11px] text-[#8c8072]">
            <p>{footerConfig.copyrightText || 'Academic Study Hub'}</p>
          </div>
        </div>
      </div>
    </footer>
  );
};
