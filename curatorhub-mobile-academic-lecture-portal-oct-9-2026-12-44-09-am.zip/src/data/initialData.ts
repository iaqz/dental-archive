import { HubData } from '../types/hub';

export const INITIAL_HUB_DATA: HubData = {
  version: 2,
  updatedAt: new Date().toISOString(),
  config: {
    hubTitle: "DentMed Academic Hub",
    hubSubtitle: "Curated lectures, NotebookLM MCQs, flashcards & sources",
    institutionName: "Faculty of Dentistry & Oral Medicine",
    announcement: {
      text: "NotebookLM study guides and MCQs updated for all lectures.",
      active: true,
    },
    adminPasscode: "20071507@a",
    footerConfig: {
      title: "DentMed Academic Archive",
      subtitle: "Organized for quick mobile revision. Publicly accessible to all students.",
      batchOrClass: "Class of 2026 / 2027",
      customNote: "Maintained by your academic reps. Links connect directly to lecture materials and NotebookLM study spaces.",
      copyrightText: "DentMed Hub • Free for all students",
    },
  },
  subjects: [
    {
      id: "histology",
      name: "Histology",
      code: "HIST-201",
      description: "Oral mucosa, epithelial junctions, amelogenesis, and dentinogenesis.",
      iconName: "Microscope",
      themeColor: "terracotta",
      order: 1,
    },
    {
      id: "embryology",
      name: "Embryology",
      code: "EMBR-202",
      description: "Pharyngeal arches, craniofacial development, and palatogenesis.",
      iconName: "Sparkles",
      themeColor: "amber",
      order: 2,
    },
    {
      id: "prosthodontics",
      name: "Prosthodontics",
      code: "PROS-203",
      description: "Anatomical landmarks, border molding, and complete denture mechanics.",
      iconName: "Smile",
      themeColor: "bronze",
      order: 3,
    },
  ],
  lectures: [
    {
      id: "hist-lec-1",
      subjectId: "histology",
      lectureNumber: 1,
      title: "Oral Mucosa & Epithelial Cell Junctions",
      overview: "Stratified squamous epithelium, desmosomes, hemidesmosomes, masticatory vs lining mucosa, and Langerhans & Merkel cells.",
      status: "completed",
      primaryLink: {
        label: "Open Lecture Slides",
        url: "https://docs.google.com/presentation/d/sample-histology-1",
      },
      mcqLink: {
        label: "NotebookLM MCQs & Quiz",
        url: "https://notebooklm.google.com",
        note: "Auto-generated clinical MCQs from lecture transcript",
      },
      flashcardLink: {
        label: "NotebookLM Study Guide & Cards",
        url: "https://notebooklm.google.com",
        note: "Key histology concepts & cell junction recall",
      },
      attachments: [
        {
          id: "hist-att-1",
          title: "Lecture Recording Video",
          url: "https://youtube.com",
          type: "video",
          description: "Full audio and whiteboard explanation."
        },
        {
          id: "hist-att-2",
          title: "Histology Guide Virtual Microscope Atlas",
          url: "https://histologyguide.com",
          type: "source",
          description: "High-resolution digital slides of oral epithelium."
        },
        {
          id: "hist-att-3",
          title: "Summary Handout (PDF)",
          url: "https://drive.google.com",
          type: "pdf",
          description: "2-page high-yield review notes."
        }
      ]
    },
    {
      id: "hist-lec-2",
      subjectId: "histology",
      lectureNumber: 2,
      title: "Enamel Structure & Amelogenesis",
      overview: "Enamel rods, Striae of Retzius, Hunter-Schreger bands, and Tomes' process secretory phases.",
      status: "completed",
      primaryLink: {
        label: "Open Notion Master Notes",
        url: "https://notion.so",
      },
      mcqLink: {
        label: "NotebookLM MCQs & Quiz",
        url: "https://notebooklm.google.com",
        note: "Amelogenesis stages & mineral composition QBank",
      },
      flashcardLink: {
        label: "NotebookLM Flashcards",
        url: "https://notebooklm.google.com",
        note: "96% mineralized matrix & rod directions",
      },
      attachments: [
        {
          id: "hist-att-4",
          title: "3D Amelogenesis Mechanism Video",
          url: "https://youtube.com",
          type: "video",
          description: "Animation showing ameloblast movement vector."
        },
        {
          id: "hist-att-5",
          title: "Ten Cate's Oral Histology (Chapter 7)",
          url: "https://pubmed.ncbi.nlm.nih.gov",
          type: "source",
          description: "Textbook reference reading."
        }
      ]
    },
    {
      id: "embr-lec-1",
      subjectId: "embryology",
      lectureNumber: 1,
      title: "Pharyngeal Arches & Facial Prominences",
      overview: "Derivatives of the first and second branchial arches, Meckel's cartilage, CN V3 and CN VII innervation, and maxillary/mandibular process fusion.",
      status: "completed",
      primaryLink: {
        label: "Download Lecture Handout",
        url: "https://drive.google.com",
      },
      mcqLink: {
        label: "NotebookLM MCQs & Quiz",
        url: "https://notebooklm.google.com",
        note: "Pharyngeal arch derivatives test set",
      },
      flashcardLink: {
        label: "NotebookLM Flashcards",
        url: "https://notebooklm.google.com",
        note: "Arches, pouches, and clefts breakdown",
      },
      attachments: [
        {
          id: "embr-att-1",
          title: "Craniofacial Morphogenesis 3D Video",
          url: "https://youtube.com",
          type: "video",
          description: "Neural crest cell migration walkthrough."
        },
        {
          id: "embr-att-2",
          title: "Langman's Medical Embryology Reference",
          url: "https://pubmed.ncbi.nlm.nih.gov",
          type: "source",
          description: "Core embryology chapter."
        }
      ]
    },
    {
      id: "pros-lec-1",
      subjectId: "prosthodontics",
      lectureNumber: 1,
      title: "Maxillary & Mandibular Anatomical Landmarks",
      overview: "Limiting, supporting, and relief areas for complete dentures: buccal shelf, retromolar pad, vibrating line, hamular notch, and incisive papilla.",
      status: "completed",
      primaryLink: {
        label: "Clinical Protocol Drive",
        url: "https://drive.google.com",
      },
      mcqLink: {
        label: "NotebookLM MCQs & Quiz",
        url: "https://notebooklm.google.com",
        note: "Stress-bearing areas & seal lines quiz",
      },
      flashcardLink: {
        label: "NotebookLM Flashcards",
        url: "https://notebooklm.google.com",
        note: "Definitions of PPS, fovea palatinae & notches",
      },
      attachments: [
        {
          id: "pros-att-1",
          title: "Border Molding Clinical Video",
          url: "https://youtube.com",
          type: "video",
          description: "Step-by-step custom tray border tracing."
        },
        {
          id: "pros-att-2",
          title: "Boucher's Clinical Prosthodontics Guide",
          url: "https://drive.google.com",
          type: "pdf",
          description: "Standard edentulous landmarks reference."
        }
      ]
    }
  ]
};
