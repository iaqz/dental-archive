import React, { useState, useEffect, useMemo } from 'react';
import { 
  HubData, 
  Subject, 
  Lecture, 
  AttachmentItem 
} from './types/hub';
import { 
  loadLocalHubData, 
  subscribeToCloudHub, 
  saveHubDataToCloud, 
  resetCloudHubToDefault,
  checkAdminSession,
  setAdminSession 
} from './utils/storage';
import { Header } from './components/Header';
import { SubjectBar } from './components/SubjectBar';
import { LectureCard } from './components/LectureCard';
import { Footer } from './components/Footer';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminEditLectureModal } from './components/AdminEditLectureModal';
import { AdminEditSubjectModal } from './components/AdminEditSubjectModal';
import { AdminHubSettingsModal } from './components/AdminHubSettingsModal';
import { AdminEditAttachmentModal } from './components/AdminEditAttachmentModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { EditNoticeModal } from './components/EditNoticeModal';
import { ToothIcon, renderSectionIcon } from './components/DentalIcons';
import { 
  Plus, 
  BookOpen
} from 'lucide-react';

export default function App() {
  // Live Cloud Synchronized Hub Data State
  const [hubData, setHubData] = useState<HubData>(() => loadLocalHubData());
  const [syncStatus, setSyncStatus] = useState<'synced' | 'saving' | 'offline' | 'error'>('synced');
  const [isAdmin, setIsAdmin] = useState<boolean>(() => checkAdminSession());
  
  // Navigation & Filtering State (default to first subject)
  const [activeSubjectId, setActiveSubjectId] = useState<string | null>('histology');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEditNoticeOpen, setIsEditNoticeOpen] = useState(false);

  // Deletion Confirmation State (in-app modal)
  const [deleteLectureTarget, setDeleteLectureTarget] = useState<{ id: string; title: string } | null>(null);
  const [deleteSubjectTarget, setDeleteSubjectTarget] = useState<{ id: string; name: string } | null>(null);

  // Lecture Edit/Create Modal State
  const [editingLecture, setEditingLecture] = useState<{
    isOpen: boolean;
    lecture?: Lecture | null;
  }>({ isOpen: false, lecture: null });

  // Subject Edit/Create Modal State
  const [editingSubject, setEditingSubject] = useState<{
    isOpen: boolean;
    subject?: Subject | null;
  }>({ isOpen: false, subject: null });

  // Attachment Edit Modal State
  const [editingAttachment, setEditingAttachment] = useState<{
    isOpen: boolean;
    lectureId?: string;
    attachment?: AttachmentItem | null;
  }>({ isOpen: false });

  // Subscribe to real-time cloud updates from Firestore
  // Changes on phone appear on PC and all students immediately!
  useEffect(() => {
    const unsubscribe = subscribeToCloudHub(
      (cloudData) => {
        setHubData(cloudData);
      },
      (status) => {
        setSyncStatus(status);
      }
    );

    return () => unsubscribe();
  }, []);

  // Helper to commit changes to cloud
  const commitData = async (updater: (prev: HubData) => HubData) => {
    setSyncStatus('saving');
    const nextData = updater(hubData);
    setHubData(nextData);
    const ok = await saveHubDataToCloud(nextData);
    setSyncStatus(ok ? 'synced' : 'offline');
  };

  // Auth Handlers (passcode strictly 20071507@a)
  const handleAdminLogin = (passcode: string): boolean => {
    if (passcode === '20071507@a' || passcode === hubData.config.adminPasscode) {
      setIsAdmin(true);
      setAdminSession(true);
      return true;
    }
    return false;
  };

  const handleAdminLogout = () => {
    setIsAdmin(false);
    setAdminSession(false);
  };

  // Helper counts
  const getSubjectLectureCount = (subId: string) => {
    return hubData.lectures.filter((l) => l.subjectId === subId).length;
  };

  // Filtered lectures sorted by lecture number
  const filteredLectures = useMemo(() => {
    return hubData.lectures.filter((lec) => {
      // Filter by active subject if chosen
      if (activeSubjectId && lec.subjectId !== activeSubjectId) {
        return false;
      }
      // Filter by search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = lec.title.toLowerCase().includes(q);
        const matchesOverview = lec.overview?.toLowerCase().includes(q) || false;
        const matchesAttachments = lec.attachments?.some(
          (a) => a.title.toLowerCase().includes(q) || a.description?.toLowerCase().includes(q)
        ) || false;

        return matchesTitle || matchesOverview || matchesAttachments;
      }
      return true;
    }).sort((a, b) => a.lectureNumber - b.lectureNumber);
  }, [hubData.lectures, activeSubjectId, searchQuery]);

  // Lecture CRUD Operations (Live Cloud Sync)
  const handleSaveLecture = (savedLecture: Lecture) => {
    commitData((prev) => {
      const exists = prev.lectures.some((l) => l.id === savedLecture.id);
      let updatedLectures: Lecture[];
      if (exists) {
        updatedLectures = prev.lectures.map((l) => (l.id === savedLecture.id ? savedLecture : l));
      } else {
        updatedLectures = [...prev.lectures, savedLecture];
      }
      return { ...prev, lectures: updatedLectures };
    });
  };

  const handleConfirmDeleteLecture = () => {
    if (!deleteLectureTarget) return;
    const targetId = deleteLectureTarget.id;
    commitData((prev) => ({
      ...prev,
      lectures: prev.lectures.filter((l) => l.id !== targetId),
    }));
    setDeleteLectureTarget(null);
  };

  // Subject CRUD Operations (Supports adding any new section like Biology)
  const handleSaveSubject = (savedSubject: Subject) => {
    commitData((prev) => {
      const exists = prev.subjects.some((s) => s.id === savedSubject.id);
      let updatedSubjects: Subject[];
      if (exists) {
        updatedSubjects = prev.subjects.map((s) => (s.id === savedSubject.id ? savedSubject : s));
      } else {
        updatedSubjects = [...prev.subjects, savedSubject];
      }
      return { ...prev, subjects: updatedSubjects };
    });
    // Immediately select the newly created section so user sees it right away
    setActiveSubjectId(savedSubject.id);
  };

  const handleConfirmDeleteSubject = () => {
    if (!deleteSubjectTarget) return;
    const targetId = deleteSubjectTarget.id;
    commitData((prev) => ({
      ...prev,
      subjects: prev.subjects.filter((s) => s.id !== targetId),
      lectures: prev.lectures.filter((l) => l.subjectId !== targetId),
    }));
    if (activeSubjectId === targetId) {
      const remaining = hubData.subjects.filter((s) => s.id !== targetId);
      setActiveSubjectId(remaining[0]?.id || null);
    }
    setDeleteSubjectTarget(null);
  };

  // Attachment Operations (Live Cloud Sync)
  const handleSaveAttachment = (att: AttachmentItem) => {
    if (!editingAttachment.lectureId) return;
    const targetLecId = editingAttachment.lectureId;
    commitData((prev) => ({
      ...prev,
      lectures: prev.lectures.map((lec) => {
        if (lec.id !== targetLecId) return lec;
        const exists = lec.attachments.some((a) => a.id === att.id);
        const updatedAtts = exists
          ? lec.attachments.map((a) => (a.id === att.id ? att : a))
          : [...lec.attachments, att];
        return { ...lec, attachments: updatedAtts };
      }),
    }));
  };

  const handleDeleteAttachment = (lectureId: string, attId: string) => {
    commitData((prev) => ({
      ...prev,
      lectures: prev.lectures.map((lec) => {
        if (lec.id !== lectureId) return lec;
        return {
          ...lec,
          attachments: lec.attachments.filter((a) => a.id !== attId),
        };
      }),
    }));
  };

  // Notice Update (Live Cloud Sync)
  const handleSaveNotice = (newNotice: string) => {
    commitData((prev) => ({
      ...prev,
      config: {
        ...prev.config,
        footerConfig: {
          ...prev.config.footerConfig,
          customNote: newNotice,
        },
      },
    }));
  };

  // Current active subject info
  const currentSubject = hubData.subjects.find((s) => s.id === activeSubjectId);

  return (
    <div className="min-h-screen bg-[#faf7f2] text-[#2d2822] flex flex-col justify-between">
      {/* Mobile-first centered wrapper */}
      <div className="w-full max-w-xl mx-auto flex flex-col flex-1">
        {/* Header with Return to Viewer capability and live cloud badge */}
        <Header
          config={hubData.config}
          onSelectSubject={setActiveSubjectId}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          isAdmin={isAdmin}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onLogoutAdmin={handleAdminLogout}
          syncStatus={syncStatus}
        />

        {/* Main Content Area */}
        <main className="flex-1 px-4 py-3 space-y-3.5">
          {/* Categories / Sections with custom chosen icons */}
          <SubjectBar
            subjects={hubData.subjects}
            activeSubjectId={activeSubjectId}
            onSelectSubject={setActiveSubjectId}
            getLectureCount={getSubjectLectureCount}
            isAdmin={isAdmin}
            onAddSubject={() => setEditingSubject({ isOpen: true, subject: null })}
            onEditSubject={(sub) => setEditingSubject({ isOpen: true, subject: sub })}
          />

          {/* Active Category Title & Admin Add Button */}
          <div className="flex items-center justify-between gap-2 pt-1 pb-1">
            <div className="flex items-center gap-1.5">
              {currentSubject ? (
                renderSectionIcon(currentSubject.iconName, "w-4 h-4 text-[#a85012]")
              ) : (
                <ToothIcon className="w-3.5 h-3.5 text-[#a85012]" />
              )}
              <h2 className="text-sm font-bold text-[#2d2822]">
                {currentSubject ? currentSubject.name : 'All Lectures'}
              </h2>
              <span className="text-xs text-[#8c8072]">
                ({filteredLectures.length} {filteredLectures.length === 1 ? 'lecture' : 'lectures'})
              </span>
            </div>

            {isAdmin && (
              <button
                onClick={() =>
                  setEditingLecture({
                    isOpen: true,
                    lecture: null,
                  })
                }
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-[#c2621c] hover:bg-[#ad5313] text-[#fffdfa] transition shadow-2xs active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Lecture</span>
              </button>
            )}
          </div>

          {/* Simplified Lecture Cards List */}
          {filteredLectures.length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#f7f2ea] border border-[#e4d8c7] text-center my-6">
              <BookOpen className="w-8 h-8 text-[#a39786] mx-auto mb-2" />
              <h3 className="text-sm font-bold text-[#2d2822]">
                {currentSubject ? `No lectures yet in ${currentSubject.name}` : 'No lectures found'}
              </h3>
              <p className="text-xs text-[#7d7162] mt-1 max-w-xs mx-auto">
                {searchQuery
                  ? `No lectures matching "${searchQuery}".`
                  : 'Get started by adding your first lecture to this section.'}
              </p>
              {isAdmin && (
                <button
                  onClick={() =>
                    setEditingLecture({
                      isOpen: true,
                      lecture: null,
                    })
                  }
                  className="mt-3 px-4 py-2 rounded-xl text-xs font-semibold bg-[#c2621c] text-[#fffdfa] hover:bg-[#ad5313] transition cursor-pointer"
                >
                  + Add First Lecture to {currentSubject?.name || 'Section'}
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredLectures.map((lec) => (
                <LectureCard
                  key={lec.id}
                  lecture={lec}
                  isAdmin={isAdmin}
                  onEditLecture={(l) => setEditingLecture({ isOpen: true, lecture: l })}
                  onRequestDelete={(id, title) => setDeleteLectureTarget({ id, title })}
                  onAddAttachment={() =>
                    setEditingAttachment({ isOpen: true, lectureId: lec.id, attachment: null })
                  }
                  onEditAttachment={(att) =>
                    setEditingAttachment({ isOpen: true, lectureId: lec.id, attachment: att })
                  }
                  onDeleteAttachment={(attId) => handleDeleteAttachment(lec.id, attId)}
                />
              ))}
            </div>
          )}
        </main>

        {/* Clean Footer (No Backup option) */}
        <Footer
          footerConfig={hubData.config.footerConfig}
          isAdmin={isAdmin}
          onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenEditNotice={() => setIsEditNoticeOpen(true)}
          onExitAdminMode={handleAdminLogout}
        />
      </div>

      {/* MODALS */}
      {/* 1. Admin Login Modal (password 20071507@a, NO suggestions) */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onLogin={handleAdminLogin}
      />

      {/* 2. Admin Edit Lecture Modal */}
      <AdminEditLectureModal
        isOpen={editingLecture.isOpen}
        onClose={() => setEditingLecture({ isOpen: false, lecture: null })}
        onSave={handleSaveLecture}
        subjects={hubData.subjects}
        initialLecture={editingLecture.lecture}
        defaultSubjectId={activeSubjectId || hubData.subjects[0]?.id}
      />

      {/* 3. Admin Edit Subject Modal (with Icon Chooser) */}
      <AdminEditSubjectModal
        isOpen={editingSubject.isOpen}
        onClose={() => setEditingSubject({ isOpen: false, subject: null })}
        onSave={handleSaveSubject}
        onDelete={(id) => {
          const sub = hubData.subjects.find((s) => s.id === id);
          if (sub) {
            setDeleteSubjectTarget({ id, name: sub.name });
          }
        }}
        initialSubject={editingSubject.subject}
      />

      {/* 4. Attachment Add/Edit Modal */}
      <AdminEditAttachmentModal
        isOpen={editingAttachment.isOpen}
        onClose={() => setEditingAttachment({ isOpen: false })}
        onSave={handleSaveAttachment}
        initialAttachment={editingAttachment.attachment}
      />

      {/* 5. In-App Delete Lecture Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteLectureTarget !== null}
        title="Delete Lecture"
        message={`Are you sure you want to permanently delete "${deleteLectureTarget?.title}"? All associated links and attachments will be removed.`}
        onConfirm={handleConfirmDeleteLecture}
        onCancel={() => setDeleteLectureTarget(null)}
      />

      {/* 6. In-App Delete Subject Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteSubjectTarget !== null}
        title="Delete Section"
        message={`Are you sure you want to delete "${deleteSubjectTarget?.name}" and all its lectures?`}
        onConfirm={handleConfirmDeleteSubject}
        onCancel={() => setDeleteSubjectTarget(null)}
      />

      {/* 7. Edit Notice Modal */}
      <EditNoticeModal
        isOpen={isEditNoticeOpen}
        currentNotice={hubData.config.footerConfig.customNote}
        onClose={() => setIsEditNoticeOpen(false)}
        onSave={handleSaveNotice}
      />

      {/* 8. Admin Hub Settings Modal */}
      <AdminHubSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={hubData.config}
        onSaveConfig={async (cfg) => {
          commitData((prev) => ({ ...prev, config: cfg }));
        }}
        onResetHub={async () => {
          const fresh = await resetCloudHubToDefault();
          setHubData(fresh);
        }}
      />
    </div>
  );
}
